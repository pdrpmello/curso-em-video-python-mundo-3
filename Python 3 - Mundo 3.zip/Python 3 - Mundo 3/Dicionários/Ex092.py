# Crie um programa que leia nome, ano de nascimento e carteira de trabalho e cadastre-o (com idade) em um dicionário.
# Se por acaso a CTPS for diferente de ZERO, o dicionário receberá também o ano de contratação e o salário. Calcule e acrescente, além da idade, com quantos anos a pessoa vai se aposentar.

# Cálculos feitos supondo que a idade média de aposentadoria no Brasil em 2024 seja 60 anos para ambos os sexos.

from datetime import datetime

while True:
    data = dict()

    data['name'] = str(input("Digite o seu nome: "))
    birth = int(input("Digite o ano de seu nascimento: "))
    data['age'] = datetime.now().year - birth
    data['hired'] = int(input("Digite o ano de contratação: "))
    data['compensation'] = input("Digite o seu salário: R$ ")
    data['CTPS'] = int(input("Digite o número da sua carteira de trabalho: "))

    if data['CTPS'] != 0:
        retirement_year = birth + 60
        retirement_age = retirement_year - datetime.now().year
        print(f"Obrigado por se cadastrar no programa! De acordo com os cálculos, você vai se aposentar daqui a {retirement_age} anos.")
    else: 
        print("Obrigado por se cadastrar no programa! Você ainda não está trabalhando, portanto o cálculo de aposentadoria não será possível.")
    
    again = str(input("Deseja efetuar o cálculo para mais alguma pessoa? [S/N] ")).upper()
    if again != 'S':
        break

print("Programa encerrado.")