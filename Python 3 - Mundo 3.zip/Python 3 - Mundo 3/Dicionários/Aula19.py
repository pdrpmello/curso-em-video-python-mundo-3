# Um dicionário em Python é uma estrutura de dados que permite armazenar dados em pares. Chamamos cada par de dados de par chave-valor. Assim, cada elemento em um dicionário consiste em uma
# chave e um valor associado a essa chave.
# Podemos utilizar esta associação para representar relações que existem no mundo real, como um produto e seu preço.

pessoa = {"nome": "Paulo", "idade": 29, "filhos": ["João", "Maria"]}

# Veja que, para criar um dicionário em Python, basta utilizar chaves ( { } ) e inserir os pares de chave-valor separados por vírgula ( , ).
# Por fim, fazemos a associação entre cada chave e seu respectivo valor com o sinal de dois-pontos ( : ).

# CHAVES
# Seguindo com a analogia anterior, as chaves de um dicionário representam o “nome” de um atributo, a partir do qual acessamos o valor. Com frequência, utilizamos strings como chaves de
# dicionários, embora também possamos utilizar outros tipos de dados, como números ou tuplas. A única restrição é que um tipo de dado mutável (como uma lista) não pode ser uma chave de um
# dicionário.

# Outro ponto importante é que as chaves de dicionários em Python são únicas: não podemos ter a mesma chave associada a dois ou mais valores do dicionário ao mesmo tempo.

# VALORES
# O que é o valor de um dicionário Python?
# Os valores de um dicionário representam cada dado ou informação associado a uma determinada chave. Podemos fazer uma analogia entre um dicionário em Python e um dicionário escolar
# tradicional: assim como em um dicionário tradicional cada palavra está associada à sua definição, nos dicionários em Python cada chave está associada ao seu valor.

# Qualquer tipo de dado pode ser um valor em um dicionário: strings, listas, valores booleanos, tuplas… até mesmo outros dicionários são valores válidos para um dicionário.
# Note que isso permite que criemos estruturas de dados aninhadas de forma arbitrária, com dicionários dentro de dicionários ou listas dentro de dicionários.

# COMO ACESSAR UM VALOR EM PYTHON
# Para acessar um valor em um dicionário Python, precisamos acessar a variável do dicionário e passar a sua chave entre colchetes ( [ ] ).
# Por exemplo, se tivermos um dicionário que associa países a suas respectivas capitais, podemos acessar a capital de um país qualquer com a construção dicionario["nome_do_pais"].

capitais = {"Brasil": "Brasília", "Alemanha": "Berlim", "Japão": "Tóquio"}
capital_brasil = capitais["Brasil"]
print(capital_brasil)

# output:
# Brasília

# Aqui a construção capitais["Brasil"] é usada para “pegar” o valor associado à chave "Brasil" de dentro do dicionário. Assim, quando exibimos o seu valor com a função print(), o texto Brasília
# é exibido.

# Mas atenção! Se tentarmos pegar um valor de uma chave que não existe no dicionário, encontraremos um KeyError, o que terminará a execução do nosso programa:

capitais = {"Brasil": "Brasília", "Alemanha": "Berlim", "Japão": "Tóquio"}
capital_italia = capitais["Itália"]  # KeyError: 'Itália'