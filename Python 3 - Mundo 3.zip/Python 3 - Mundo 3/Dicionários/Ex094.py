# Crie um programa que leia nome, sexo e idade de várias pessoas, guardando os dados de cada pessoa em um dicionário e todos os dicionários em uma lista.
# No final, mostre: A) Quantas pessoas foram cadastradas B) A média de idade C) Uma lista com as mulheres D) Uma lista de pessoas com idade acima da média

data = []
user = {}
sum_age = 0
while True:
    user = {}
    user['name'] = str(input("Nome: "))
    user['sexuality'] = str(input("Sexo [M/F] ")).upper()
    while user['sexuality'] not in 'MF':
        print("Erro! Digite apenas M ou F.")
        user['sexuality'] = str(input("Sexo [M/F] ")).upper()
        
    user['age'] = int(input("Idade: "))
    sum_age += user['age']
    
    data.append(user.copy())
    
    new = str(input("Deseja continuar? [S/N] ")).upper()
    while new not in 'SN':
        print("Erro! Digite apenas S ou N.")
        new = str(input("Deseja continuar? [S/N] ")).upper()
        
    if new == 'N':
        break

mean_age = sum_age / len(data)
print("-" *30)
print(f"A) Foram cadastradas {len(data)} pessoas ao todo.")
print(f"B) A média de idade das pessoas cadastradas é {mean_age:.2f}")
print("C) As mulheres cadastradas são: ", end='')
for user in data:
    if user['sexuality'] == 'F':
        print(f"{user['name']}", end=' ')
print()
print("D) Lista das pessoas que estão com a idade acima da média: ", end='')
for user in data:
    if user['age'] > mean_age:
        print(f"{user['name']}", end=' ')