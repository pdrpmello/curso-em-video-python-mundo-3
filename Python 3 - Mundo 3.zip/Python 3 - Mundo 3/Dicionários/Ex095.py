# Aprimore o desafio 93 para que ele funcione com vários jogadores, incluindo um sistema de visualização de detalhes do aproveitamento de cada jogador.

data = []
players = {}

while True:
    players['player'] = str(input("Digite o nome do jogador: "))
    players['games'] = int(input("Digite quantos jogos esse jogador jogou: "))
    players['scores'] = int(input("Digite o número de gols feitos: "))
    again = str(input("Deseja efetuar o cálculo para mais alguma pessoa? [S/N] ")).upper()
    while again not in 'SN':
        again = str(input("Deseja efetuar o cálculo para mais alguma pessoa? [S/N] ")).upper()
    
    data.append(players.copy())

    if again != 'S':
        break

print("Programa encerrado.")
print(players)

performance = players["scores"] / players["games"]
print(f"O jogador {players['player']} jogou {players['games']} jogos e marcou {players['scores']} gols. O seu aproveitamento é de {performance} gols por jogo.")