# Crie um programa que gerencie o aproveitamento de um jogador de futebol. O programa vai ler o nome do jogador e quantas partidas ele jogou.
# Depois vai ler a quantidade de gols feitos em cada partida. No final, tudo isso será guardado em um dicionário, incluindo o total de gols feitos durante o campeonato.

while True:
    data = dict()

    data['player'] = str(input("Digite o nome do jogador: "))
    data['games'] = int(input("Digite quantos jogos esse jogador jogou: "))
    data['scores'] = int(input("Digite o número de gols feitos: "))
    again = str(input("Deseja efetuar o cálculo para mais alguma pessoa? [S/N] ")).upper()

    while again not in 'SN':
        again = str(input("Deseja efetuar o cálculo para mais alguma pessoa? [S/N] ")).upper()
    if again != 'S':
        break

print("Programa encerrado.")
print(data)

performance = data["scores"] / data["games"]
print(f"O jogador {data['player']} jogou {data['games']} jogos e marcou {data['scores']} gols. O seu aproveitamento é de {performance} gols por jogo.")