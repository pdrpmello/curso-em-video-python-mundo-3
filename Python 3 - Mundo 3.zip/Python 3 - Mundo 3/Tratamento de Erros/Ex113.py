# Reescreva a função leiaInt() que fizemos no desafio 104, incluindo agora a possibilidade da digitação de um número de tipo inválido.
# Aproveite e crie também uma função leiaFloat() com a mesma funcionalidade.

def readinteger():
    return int(input("Digite um número inteiro: "))


def readfloat():
    return float(input("Digite um número de ponto flutuante: "))

try:
    a = readinteger()
    b = readfloat()
except:
    print("Infelizmente tivemos um problema.")
else:
    print(f"Muito bem! O número inteiro que você escolheu é {a}")
    print(f"Muito bem! O número de ponto flutuante que você escolheu é {b}")