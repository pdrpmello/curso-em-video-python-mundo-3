# Crie um código em Python que teste se o site pudim está acessível pelo computador usado.

import urllib.request

try:
    site = urllib.request.urlopen("https://www.cursoemvideo.com/curso/python-3-mundo-3/aulas/tratamento-de-erros-em-python/modulos/exercicio-114-site-esta-acessivel/")
except:
    print("Deu erro.")
else:
    print("Deu certo!")