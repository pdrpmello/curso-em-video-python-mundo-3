def linha(tam=42):
    return '-' * tam


def cabecalho(txt):
    print(linha())
    print(txt.center(42))
    print(linha())


def menu(list):
    cabecalho('Menu Principal')
    c = 1
    for item in list:
        print(f"{c} - {item}")
        c += 1
    print(linha())
    opc = leiaInt('Sua opção: ')
    return opc


def leiaInt(msg):
    while True:
        try:
            valor = int(input(msg))
            return valor
        except ValueError:
            print('Erro! Digite um número inteiro válido.')

def archive(name):
    try:
        a = open(name, 'rt')
        a.close()
    except FileNotFoundError:
        return False
    else:
        return True

        


# menu(['Ver pessoas cadastradas', 'Cadastrar nova pessoa', 'Sair do programa'])

from time import sleep

archive = 'cursoemvideopython.txt'

if archive(archive):
    print("Arquivo encontrado com sucesso.")
else:
    print("Arquivo não encontrado.")

while True:
    resposta = menu(['Ver pessoas cadastradas', 'Cadastrar nova pessoa', 'Sair do programa'])
    if resposta == 1:
        print("Opção 1")
    elif resposta == 2:
        print("Opção 2")
    elif resposta == 3:
        print("Saindo do sistema... Até a próxima!")
        break
    else:
        print("Erro. Digite uma opção válida.")
    sleep(2)
