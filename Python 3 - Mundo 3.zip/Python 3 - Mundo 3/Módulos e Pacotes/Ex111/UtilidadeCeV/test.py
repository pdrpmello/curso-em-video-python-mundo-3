from Ex111.UtilidadeCeV import Moeda, Dado

price = float(input("Please enter a price: $"))
Moeda.summary_currency(price, 20, 12)