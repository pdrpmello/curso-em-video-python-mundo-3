def increase_price(price = 0, rate = 0, currency = 'R$'):
    return type_currency(price + (price * rate / 100), currency)


def decrease_price(price = 0, rate = 0, currency = 'R$'):
    return type_currency(price - (price * rate / 100), currency)


def multiply_price(price = 0, multiplier = 1, currency = 'R$'):
    return type_currency(price * multiplier , currency)


def divide_price(price = 0, divider = 1, currency = 'R$'):
    return type_currency(price / divider, currency)


def type_currency(price = 0, currency = 'R$'):
    return f'{currency}{price:>.2f}'.replace('.', ',')


# Ex110
def summary_currency(price=0, rate=0, multiplier=1, divider=1, currency='R$'):
    print('-' * 30)
    print('RESUMO DO VALOR'.center(30))
    print('-' * 30)
    print(f"Aumentando 10% do preço, temos {increase_price(price, 10)}")
    print(f"Diminuindo 10% do preço, temos {decrease_price(price, 10)}")
    print(f"O preço {type_currency(price, 'R$')} multiplicado por {multiplier} é {multiply_price(price, multiplier)}")
    print(f"A preço {type_currency(price, 'R$')} dividido por {divider} é {divide_price(price, divider)}")
    print('-' * 30)