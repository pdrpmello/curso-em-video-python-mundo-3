# Crie um módulo chamado moeda.py que tenha as funções incorporadas aumentar(), diminuir(), dobro() e metade(). Faça também um programa que importe esse módulo e use algumas dessas funções.

import moeda

price = int(input("Digite o preço: R$"))
print(f"Aumentando 10% do preço, temos {moeda.aumentar(price, 10)}.")
print(f"Diminuindo 10% do preço, temos {moeda.diminuir(price, 10)}.")
print(f"O dobro de {price} é {moeda.dobro(price):.2f}.")
print(f"A metade de {price} é {moeda.metade(price):.2f}.")