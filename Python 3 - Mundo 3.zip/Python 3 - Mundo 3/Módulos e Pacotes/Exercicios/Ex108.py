# Adapte o código do desafio #107, criando uma função adicional chamada moeda() que consiga mostrar os números como um valor monetário formatado.

import moeda

price = int(input("Digite o preço: R$"))
multiplier = int(input("Digite um multiplicador: "))
while multiplier == 0:
    print("Multiplicador inválido.")
    multiplier = int(input("Digite um multiplicador: "))

divider = int(input("Digite um divisor: "))
while divider == 0:
    print("Divisor inválido.")
    divider = int(input("Digite um divisor: "))

print(f"Aumentando 10% do preço, temos {moeda.increase_price(price, 10)}")
print(f"Diminuindo 10% do preço, temos {moeda.decrease_price(price, 10)}")
print(f"O preço {moeda.type_currency(price, 'R$')} multiplicado por {multiplier} é {moeda.multiply_price(price, multiplier)}")
print(f"A preço {moeda.type_currency(price, 'R$')} dividido por {divider} é {moeda.divide_price(price, divider)}")