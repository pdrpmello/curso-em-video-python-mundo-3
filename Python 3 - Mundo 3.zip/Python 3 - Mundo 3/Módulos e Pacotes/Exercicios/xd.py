def pedro(texto:str):
    resposta = f'pedro {texto} pedro'
    return resposta

teste01 = pedro(texto='dexeutisarra')
teste02 = pedro(texto='peçopufavo')

print(teste01)
print(teste02)