# Crie um programa que tenha uma função fatorial() que receba dois parâmetros: o primeiro que indique o número a calcular e outro chamado show, que será um valor lógico (opcional) indicando se
# será mostrado ou não na tela o processo de cálculo do fatorial.

def fatorial(n, show=False):
    """"""
    resultado = 1
    for i in range(1, n + 1):
        resultado *= i
        if show:
            print(f"{i} x " if i < n else f"{i} = ", end="")
    if show:
        print(resultado)
    return resultado

print(fatorial(5))
print(fatorial(5, show=True))
print(fatorial(3, show=True))