# Crie um programa que tenha uma função chamada voto() que vai receber como parâmetro o ano de nascimento de uma pessoa, retornando um valor literal indicando se uma pessoa tem voto NEGADO,
# OPCIONAL e OBRIGATÓRIO nas eleições.

from datetime import datetime

def voto(nascimento):
    idade = datetime.now().year - nascimento
    if 16 <= idade < 18:
        print(f"Pessoas entre 16 e 18 anos de idade tem a opção de votar ou não. Como você tem {idade}, o seu voto é opcional.")
    elif idade >= 18:
        print(f"O seu voto é obrigatório pois você tem {idade} anos, acima da idade obrigatória de 18 anos.")
    else:
        print(f"Você não pode votar, pois tem apenas {idade}. Somente pessoas maiores de 16 anos de idade votam.")

while True:
    nascimento = int(input("Digite o ano do seu nascimento: "))
    voto(nascimento)
    while True:
        continuar = input("Deseja continuar? [S/N]  ").upper()
        if continuar not in 'SN':
            print("Comando inválido. Digite S ou N para a operação ser válida.")
        elif continuar == 'S':
            break
        else:
            print("Programa encerrado.")
            exit()