# Faça um programa que tenha uma função notas() que pode receber várias notas de alunos e vai retornar um dicionário com as seguintes informações:

# a) a quantidade de notas
# b) a maior nota da turma
# c) a menor nota da turma
# d) a média das notas da turma
# e) situação (opcional)

def notas(*n, situacao=False):
    relatorio = {}
    relatorio['Quantidade'] = len(n)
    relatorio['Maior'] = max(n)
    relatorio['Menor'] = min(n)
    relatorio['Média'] = sum(n) / len(n)
    print(f"A sua maior nota é {relatorio['Maior']} e a sua menor nota é {relatorio['Menor']}.")
    if relatorio['Média'] >= 7:
        print(f"A média para aprovação é 7 e a sua média é {relatorio['Média']}. Portanto, você está aprovado!")
    else:
        print(f"A média para aprovação é 7 e a sua média é {relatorio['Média']}. Portanto, você está reprovado!")
    

notas(5, 0)