# Faça um programa que tenha uma função chamada maior(), que receba vários parâmetros com valores inteiros. Seu programa tem que analisar todos os valores e dizer qual deles é o maior.

dados = []

while True:
    numeros = int(input("Digite um número inteiro (ou digite 0 para encerrar o programa): "))
    if numeros == 0:
        break
    dados.append(numeros)

def maior(dados):
    return max(dados)

print(f"Os números armazenados foram: {dados}. O maior deles é o número {maior(dados)}.")