# INTERACTIVE HELP #

# Python help() function is used to get the documentation of specified module, class, function, variables etc. This method is generally used with python interpreter console to get details about
# python objects.

help()

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

# ESCOPO DE VARIÁVEIS #

def teste():
    x = 8
    print(f"Na função n, n vale {n}.")
    print(f"Na função x, x vale {x}.")

# Programa principal:
n = 2
print(f"No programa principal, n vale {n}.")
print(f"No programa principal, x vale {x}.")

# A variável x (linha 13) é uma variável local, pois ela foi declarada apenas para a função teste().
# A variável n (linha 18) é uma variável global, pois ela foi declarada e pode ser usada em todo o código (não indentada).