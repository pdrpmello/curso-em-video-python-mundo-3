# FUNÇÕES #

# Funções são blocos de código que executam funcionalidades específicas. Normalmente são utilizados para evitar que determinada parte do seu código sejá escrito varias vezes.
# Em Python sua sintaxe é definida usando def e atribuindo um nome a ela, veja um exemplo:

def funcao():
    print("Bloco de código")

# Observando essa função, podemos extrair algumas informações, iniciando com a palavra reservada para funções def o nome atribuido à função funcao e os parênteses () utilizado para definição dos
# dados de entrada da função, também chamados de parâmetros. Em seguida usa-se dois pontos : e abaixo o bloco de código a ser executado, que neste caso é apenas imprimir de uma string.

# Para “chamar” uma função, utilizamos o nome que foi definido, dessa forma:

def funcao():
    print("Bloco de código")


funcao()

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

# PARÂMETROS #

#Além de executar código, funções também podem receber e retornar dados. Podemos enviar dados para uma função através de seus parâmetros.

def imprime_nome(nome):
    print(f"Nome: {nome}")


imprime_nome("Erickson")
imprime_nome("Renan")
imprime_nome("Daniel")
# Nome: Erickson
# Nome: Renan
# Nome: Daniel

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

# VALORES PADRÃO (VALORES DEFAULT) #

# A utilização dos valores padrão serve para dar um valor quando quem chamou a função não passar nenhum valor para os parâmetros definidos.

def flor(flor='Rosa', cor='Vermelha'):
    print("A cor da {flor} é {cor}")


flor()
flor("Orquídea", "Azul")
# A cor da Rosa é Vermelha
# A cor da Orquídea é Azul

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

# FUNÇÃO POSICIONAL X NOMEADA

def monta_computador(cpu='', armazenamento=0, memoria=0):
    print('A configuração é: \n\t- CPU: {cpu}\n\t- Armazenamento: {armazenamento}Tb\n\t- Memória: {memoria}Gb')


monta_computador('Intel Core i9', 4, 64)
# A configuração é: 
#    - CPU: Intel Core i9
#    - Armazenamento: 4Tb
#    - Memória: 64Gb

# A função monta_computador está respeitando a posição dos parâmetros, ou seja:

# O valor "Intel Core i9" é referente ao primeiro parâmetro (cpu)
# O valor 4 é referente ao segundo parâmetro (armazenamento)
# O valor 64 se refere ao terceiro parâmetro (memoria)
# Essa é uma chamada de função posicional, ou seja: que respeita a ordem dos parâmetros.

# Outra forma de fazer essa chamada de função é utilizar os nomes dos parâmetros! Dessa forma, não é necessário respeitar a ordem de definição dos parâmetros!
# Veja o mesmo exemplo, mas agora utilizando os nomes dos parâmetros:

monta_computador(memoria=64, armazenamento=4, cpu='Intel Core i9')

# A saída será a mesma, pois como utilizamos os nomes, o Python saberá qual valor referncia qual parâmetro!

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

# PARÂMETRO (*args) #

# Caso você queira desenvolver uma função que recebe um número variável de parâmetros, você pode utilizar o parâmetro *args!
# Dessa forma, a função receberá os argumentos em forma de Tupla e você poderá processá-los com um loop for por exemplo!

def maior_30(*args):
    print(args)
    print(type(args))

    for num in args:
        if num > 30:
            print(num)


maior_30(10, 20, 30, 40, 50, 60)
# (10, 20, 30, 40, 50, 60)
# <class 'tuple'>
# 40
# 50
# 60

#A função acima irá receber todos os valores passados para função no parâmetro *args e irá iterar sobre eles com um loop for.

# PARÂMETRO (**kwargs) #

#A gora, se quiser desenvolver uma função com número variado de parâmetros nomeados, utilize **kwargs.
# Dessa forma, todos os dados passados à função serão guardados nessa variável **kwargs, em formato de um dicionário.

def dados_pessoa(**kwargs):
    print(type(kwargs))
    
    for chave, valor in kwargs.items():
        print(f"{chave}: {valor}")


dados_pessoa(nome='João', idade=35, carreira='Desenvolvedor Fullstack')
# <class 'dict'>
# nome: João
# idade: 35
# carreira: Desenvolvedor Fullstack

# FUNÇÕES COM RETORNO DE DADOS #

# As funções também podem retornar valores através da palavra reservada return.

def soma_dois_numeros(valor1, valor2):
    soma = valor1 + valor2
    return soma


valor_soma = soma_dois_numeros(32, 15)
print(valor_soma)
print(soma_dois_numeros(50, 10))
# 47
# 60

# FUNÇÕES COM RETORNOS MÚLTIPLOS #

# Funções também podem retornar múltiplos dados.

def soma_dois_numeros_e_calcula_media(valor1, valor2):
    soma = valor1 + valor2
    media = (valor1 + valor2)/2
    
    return soma, media


valor_soma = soma_dois_numeros_e_calcula_media(32, 15)
print(valor_soma)
print(soma_dois_numeros_e_calcula_media(50, 10))
# (47, 23.5)
# (60, 30.0)

# PALAVRA RESERVADA (pass) #

# Caso você deseje definir uma função sem corpo nenhum, ou seja, sem código, saiba que isso irá disparar o erro IndentationError, pois funções não podem estar vazias.
# Porém se por algum motivo precisar use a palavra reservada pass, da seguinte forma:

def funcao():
    pass

# FUNÇÃO DE UMA LINHA #

# Python possibilita a criação de funções com apenas uma linha de código.

# Definição das funções
def soma(valor1, valor2): return valor1 + valor2
def divisao(valor1, valor2): return valor1 / valor2
def multiplicacao(valor1, valor2): return valor1 * valor2

# Chamada das funções
print(soma(1, 5))
print(divisao(8, 2))
print(multiplicacao(8, 2))
# 6
# 4.0
# 16

